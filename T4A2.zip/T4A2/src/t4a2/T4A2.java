package t4a2;
import java.util.Scanner;
public class T4A2 {
Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {
        ejercicio1();
        ejercicio2();
        ejercicio3();
        ejercicio4();   
        }
    public static void ejercicio1(){
           for (int i = 1; i <=10; i++){
            System.out.println("tabla de multiplicar del " + i);
            for (int j = 1; j <= 10; j++){
                System.out.println(i + " X " + j + " = " + i*j);
            }       
    }
  }
           
    public static void ejercicio2(){
    
    
    
    Scanner obj=new Scanner (System.in);    
    System.out.println("ingresa el numero: ");

    int b = obj.nextInt();
    
    boolean esPrimo = true;

     
    for (int n = 2; n <= b; n++) {
      esPrimo = true;
      for (int i = 2; i < n; i++) {
        if (n % i == 0) {
          esPrimo = false;
          
        }
      }

      // si n es primo, se muestra por pantalla
      if (esPrimo) {
        System.out.print(n + " ");
      }
    }
    System.out.println();
  }
    public static void ejercicio3(){
    Scanner teclado = new Scanner (System.in);
      int cantidadDeElementos;
      int contador_Pares = 0;
      int contador_Impares = 0;
      int b = 0;
      int valor;
      
      
      System.out.print("inserte la cantidad de elementos que desea : ");
      cantidadDeElementos = teclado.nextInt();
      
      while(b < cantidadDeElementos ){
          System.out.println("coloque el elemento numero" + b + " : ");
          valor = teclado.nextInt();
          
          if (valor % 2 == 0){
               contador_Pares ++;
      }
          else{
              contador_Impares ++;
          }
          b ++;
 }
     System.out.println(" ");
      System.out.println("La cantidad de elementos pares son " + contador_Pares);
      System.out.println("La cantidad de elementos impares son " + contador_Impares);
}

public static void ejercicio4(){

           Scanner leer=new Scanner(System.in);
		   System.out.println("Ingresa una palabra para invertir: ");
		String cadena=leer.next();
		String invertida = "";

		for (int indice = cadena.length() - 1; indice >= 0; indice--) {

			invertida += cadena.charAt(indice);
		}
		System.out.println("Cadena original: " + cadena);
		System.out.println("Cadena invertida: " + invertida);

	}
}
